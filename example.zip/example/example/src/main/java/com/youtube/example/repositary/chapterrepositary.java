package com.youtube.example.repositary;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.youtube.example.model.Books;
import com.youtube.example.model.Chapters;
@ComponentScan
@Repository
public interface chapterrepositary extends JpaRepository<Chapters,Long> {
	public Chapters getChaptersById(Long id);


}
