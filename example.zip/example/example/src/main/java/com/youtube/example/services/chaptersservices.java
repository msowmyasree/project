package com.youtube.example.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.youtube.example.model.Books;
import com.youtube.example.model.Chapters;
import com.youtube.example.repositary.bookrepositary;
import com.youtube.example.repositary.chapterrepositary;
@ComponentScan

@Service
public class chaptersservices {
	@Autowired
	private chapterrepositary chapterrepo;
	public List<Chapters> getAllChapters() {
		List<Chapters> chapters = new ArrayList<>();
		chapterrepo.findAll().forEach(chapters::add);
		return chapters;
	}
	public Chapters getChaptersById(long id) {
		return chapterrepo.getChaptersById(id);
	}

}
