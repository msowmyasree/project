package com.youtube.example.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.youtube.example.model.Books;
import com.youtube.example.services.booksservices;
@ComponentScan
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class Bookcontroller {
@Autowired
private booksservices booksServices;

@RequestMapping("/books")
public List<Books> searchBook() {
	return booksServices.getAllBooks();
}

@RequestMapping("/books/{id}")
public Books viewBookById(@PathVariable int id) {
	return booksServices.getBookById(id);
}

}
