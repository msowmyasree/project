package com.youtube.example.services;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.youtube.example.model.Books;
import com.youtube.example.repositary.bookrepositary;

@Service
public class booksservicesimpl implements booksservices {
	private static final Logger LOGGER = LoggerFactory.getLogger(booksservicesimpl.class);
	@Autowired
	bookrepositary bookrepo;
	
	@Override
	public String welcomeMsg() {
		LOGGER.info("inside welcomeMsg --");
		return "Welcome to spring boot services";
	}

	@Override
	public List<Books> getAllBooks() {
		LOGGER.info("inside books list --");
		List<Books> books = bookrepo.findAll();
		return books;
	}

	@Override
	public Books getBookById(long id) {
		LOGGER.info("inside bookid service --");
		Optional<Books> books = bookrepo.getBookById(id);
		return  books.get();
	}
	

}
