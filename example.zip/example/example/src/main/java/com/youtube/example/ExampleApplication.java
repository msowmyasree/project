
package com.youtube.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
@EnableAutoConfiguration
@EntityScan(basePackages = {"com.youtube.example.model"})
@ComponentScan(basePackages={"com.youtube.example.repositary","com.youtube.example.controller","com.youtube.example.services","com.youtube.example"})
@SpringBootApplication
public class ExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleApplication.class, args);
	}

}
