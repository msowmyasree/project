package com.youtube.example.services;



import java.util.List;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.youtube.example.model.Books;
@ComponentScan

@Service

public interface booksservices {
	String welcomeMsg();

	public List<Books> getAllBooks();
	
	public Books getBookById(long id);

	
}
