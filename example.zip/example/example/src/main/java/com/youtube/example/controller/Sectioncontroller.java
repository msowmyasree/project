package com.youtube.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.youtube.example.model.Sections;
import com.youtube.example.repositary.sectionrepositary;
@RestController
public class Sectioncontroller {
	@Autowired
	private sectionrepositary sectionrepo;
	@GetMapping("/sections")
	public List<Sections> getAllSections(){
		  return sectionrepo.findAll();
	  }
	
}
