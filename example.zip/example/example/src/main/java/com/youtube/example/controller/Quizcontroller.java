package com.youtube.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.youtube.example.model.Quiz;
import com.youtube.example.repositary.quizrepositary;
@RestController
public class Quizcontroller {
	@Autowired
	  private quizrepositary quizrepo;
	  @GetMapping("/quiz")
	  public List<Quiz> getAllQuiz(){
		  return quizrepo.findAll();
	  }
}
