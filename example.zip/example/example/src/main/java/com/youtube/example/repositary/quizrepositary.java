package com.youtube.example.repositary;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.youtube.example.model.Quiz;

@ComponentScan
@Repository
public interface quizrepositary extends JpaRepository<Quiz,Long>{

}
