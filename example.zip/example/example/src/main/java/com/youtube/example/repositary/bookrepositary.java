package com.youtube.example.repositary;

import java.util.Optional;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.youtube.example.model.Books;
@ComponentScan
@Repository
public interface bookrepositary extends JpaRepository<Books,Long> {
	
	public Optional<Books> getBookById(long id);

}
