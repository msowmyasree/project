package com.youtube.example.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Chapters")

public class Chapters {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;
    private  String cname;
    @ManyToOne
    private Books books;
    @OneToMany(mappedBy="chapters")
	private List<Sections> sections;

    public Chapters(){
    	
    }
	public Chapters(long id, String cname) {
		super();
		this.id = id;
		this.cname = cname;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public List<Sections> getSections() {
		return sections;
	}
	public void setSections(List<Sections> sections) {
		this.sections = sections;
	}
	
    
}
