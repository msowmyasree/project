package com.youtube.example;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import com.youtube.example.model.Books;
import com.youtube.example.repositary.bookrepositary;
import com.youtube.example.services.booksservicesimpl;
@ComponentScan
@RunWith(MockitoJUnitRunner.class)

public class ExampleApplicationTests {
   
    @Mock
	private bookrepositary bookrepo;
    @InjectMocks
    booksservicesimpl bimpl;
    @Mock
	Logger logger;
    @Test
	public void getMovieByIdTest() {
		
		Optional<Books> books = Optional.ofNullable(new Books(1, "Bahubali"));
		
		when(bookrepo.getBookById(1)).thenReturn(books);
		assertEquals(1, bimpl.getBookById(1).getId());
		
	}

    @Test
   	public void insertBooks() {
   		Books books = new Books(9,"MOCKITO");
   		Books books1=new Books(10,"JUNIT");
   		List<Books> list = new ArrayList<Books>();
   		list.add(books);
   		list.add(books1);
   		when(bookrepo.findAll()).thenReturn(list);
   		assertEquals(2, bimpl.getAllBooks().size());
   	}
    
  
}
