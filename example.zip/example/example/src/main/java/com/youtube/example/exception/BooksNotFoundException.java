package com.youtube.example.exception;
public class BooksNotFoundException extends RuntimeException {

    public BooksNotFoundException(Long id) {
        super("Book id not found : " + id);
    }

}
